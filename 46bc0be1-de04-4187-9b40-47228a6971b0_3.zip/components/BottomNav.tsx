'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function BottomNav() {
  const pathname = usePathname();

  const navItems = [
    { href: '/', icon: 'ri-home-line', label: 'হোম', active: pathname === '/' },
    { href: '/play', icon: 'ri-gamepad-line', label: 'খেলুন', active: pathname === '/play' },
    { href: '/shop', icon: 'ri-shopping-bag-line', label: 'দোকান', active: pathname === '/shop' },
    { href: '/profile', icon: 'ri-user-line', label: 'প্রোফাইল', active: pathname === '/profile' },
  ];

  return (
    <div className="fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 z-50 h-16">
      <div className="grid grid-cols-4 h-full">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex flex-col items-center justify-center space-y-1 transition-colors ${
              item.active 
                ? 'text-orange-500' 
                : 'text-gray-600'
            }`}
          >
            <div className="w-5 h-5 flex items-center justify-center">
              <i className={`${item.icon} text-lg`}></i>
            </div>
            <span className="text-xs">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}