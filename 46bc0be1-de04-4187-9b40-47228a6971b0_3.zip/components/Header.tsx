'use client';

interface HeaderProps {
  title: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
}

export default function Header({ title, onBack, rightAction }: HeaderProps) {
  return (
    <div className="fixed top-0 left-0 w-full bg-gradient-to-r from-orange-500 to-red-500 text-white z-50 h-14">
      <div className="flex items-center justify-between h-full px-4">
        {onBack ? (
          <button onClick={onBack} className="w-6 h-6 flex items-center justify-center">
            <i className="ri-arrow-left-line text-xl"></i>
          </button>
        ) : (
          <div className="w-6"></div>
        )}
        
        <h1 className="text-lg font-semibold text-center flex-1">{title}</h1>
        
        <div className="w-6 h-6 flex items-center justify-center">
          {rightAction}
        </div>
      </div>
    </div>
  );
}