'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';

export default function ShopPage() {
  const router = useRouter();
  const [selectedCategory, setSelectedCategory] = useState('strikers');
  const [coins] = useState(2500);

  const categories = [
    { id: 'strikers', name: 'স্ট্রাইকার', icon: 'ri-record-circle-line' },
    { id: 'pucks', name: 'পক', icon: 'ri-checkbox-blank-circle-line' },
    { id: 'boards', name: 'বোর্ড', icon: 'ri-layout-grid-line' },
    { id: 'themes', name: 'থিম', icon: 'ri-palette-line' }
  ];

  const strikerItems = [
    { id: 1, name: 'ক্লাসিক স্ট্রাইকার', price: 0, owned: true, rarity: 'common' },
    { id: 2, name: 'গোল্ডেন স্ট্রাইকার', price: 500, owned: false, rarity: 'rare' },
    { id: 3, name: 'প্রিমিয়াম স্ট্রাইকার', price: 1000, owned: false, rarity: 'epic' },
    { id: 4, name: 'ডায়মন্ড স্ট্রাইকার', price: 2000, owned: false, rarity: 'legendary' }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-300 bg-gray-50';
      case 'rare': return 'border-blue-300 bg-blue-50';
      case 'epic': return 'border-purple-300 bg-purple-50';
      case 'legendary': return 'border-yellow-300 bg-yellow-50';
      default: return 'border-gray-300 bg-gray-50';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      <Header 
        title="দোকান" 
        onBack={() => router.back()}
        rightAction={
          <div className="flex items-center space-x-1">
            <i className="ri-coins-line text-yellow-400"></i>
            <span className="text-sm font-medium">{coins.toLocaleString()}</span>
          </div>
        }
      />
      
      <div className="pt-20 pb-20 px-4">
        {/* Categories */}
        <div className="mb-6">
          <div className="grid grid-cols-4 gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`!rounded-button p-3 rounded-xl transition-all ${
                  selectedCategory === category.id
                    ? 'bg-orange-500 text-white shadow-lg'
                    : 'bg-white text-gray-600 shadow-md'
                }`}
              >
                <div className="w-6 h-6 mx-auto mb-2 flex items-center justify-center">
                  <i className={`${category.icon} text-lg`}></i>
                </div>
                <p className="text-xs font-medium">{category.name}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Featured Item */}
        <div className="mb-6">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold mb-1">বিশেষ অফার!</h3>
                <p className="text-sm opacity-90">প্রিমিয়াম প্যাক ৫০% ছাড়ে</p>
              </div>
              <div className="w-16 h-16 overflow-hidden rounded-full">
                <img 
                  src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20premium%20gift%20box%2C%20golden%20wrapped%20present%20with%20ribbon%2C%20luxury%20packaging%20design%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20colors%20with%20soft%20gradients%2C%20centered%20composition%2C%20isolated%20on%20white%20background&width=100&height=100&seq=premium-pack&orientation=squarish"
                  alt="প্রিমিয়াম প্যাক" 
                  className="w-full h-full object-cover object-top"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Shop Items */}
        <div className="grid grid-cols-2 gap-4">
          {strikerItems.map((item) => (
            <div key={item.id} className={`border-2 rounded-2xl p-4 ${getRarityColor(item.rarity)}`}>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 overflow-hidden rounded-full">
                  <img 
                    src={`https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20carom%20striker%20piece%2C%20$%7Bitem.rarity%7D%20quality%20game%20piece%2C%20metallic%20finish%2C%20detailed%20texture%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20centered%20composition%2C%20isolated%20on%20white%20background&width=100&height=100&seq=striker-${item.id}&orientation=squarish`}
                    alt={item.name} 
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                
                <h4 className="font-medium text-gray-800 text-sm mb-2">{item.name}</h4>
                
                {item.owned ? (
                  <div className="bg-green-500 text-white px-3 py-1 rounded-full text-xs">
                    মালিকানাধীন
                  </div>
                ) : (
                  <button className="!rounded-button bg-orange-500 text-white px-3 py-1 rounded-full text-xs flex items-center justify-center space-x-1 mx-auto">
                    <i className="ri-coins-line"></i>
                    <span>{item.price}</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Daily Rewards */}
        <div className="mt-8 bg-white rounded-xl p-4 shadow-md">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-gray-800">দৈনিক পুরস্কার</h3>
            <i className="ri-gift-line text-orange-500 text-xl"></i>
          </div>
          <div className="grid grid-cols-7 gap-2">
            {[1, 2, 3, 4, 5, 6, 7].map((day) => (
              <div key={day} className={`p-2 rounded-lg text-center ${
                day <= 3 ? 'bg-green-100 border border-green-300' : 'bg-gray-100 border border-gray-300'
              }`}>
                <p className="text-xs font-medium">{day}</p>
                <p className="text-xs text-gray-600 mt-1">
                  {day === 7 ? '১০০০' : '১০০'}
                </p>
              </div>
            ))}
          </div>
          <button className="!rounded-button w-full mt-3 bg-orange-500 text-white py-2 rounded-lg text-sm">
            পুরস্কার সংগ্রহ করুন
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}