
'use client';

import { useSearchParams, useRouter } from 'next/navigation';
import { useState } from 'react';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import Link from 'next/link';

export default function PlayContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const mode = searchParams.get('mode') || 'online';
  const [selectedMode, setSelectedMode] = useState(mode);

  const gameModes = [
    { id: 'classic', title: 'ক্যারাম মোড', desc: 'ক্লাসিক নিয়ম অনুসরণ করুন' },
    { id: 'diskpool', title: 'ডিস্ক পুল', desc: 'দ্রুত গতির খেলা' },
    { id: 'freestyle', title: 'ফ্রিস্টাইল', desc: 'পয়েন্ট ভিত্তিক খেলা' },
    { id: 'practice', title: 'প্র্যাকটিস', desc: 'অফলাইন চর্চা করুন' }
  ];

  const playOptions = [
    { id: 'online', title: 'অনলাইন ম্যাচ', desc: 'এলোমেলো প্রতিপক্ষ', icon: 'ri-global-line', href: '/game' },
    { id: 'friends', title: 'বন্ধুদের সাথে', desc: 'প্রাইভেট রুম তৈরি', icon: 'ri-group-line', href: '/game' },
    { id: 'tournament', title: 'টুর্নামেন্ট', desc: 'প্রতিযোগিতায় অংশ নিন', icon: 'ri-trophy-line', href: '/game' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      <Header 
        title="খেলুন" 
        onBack={() => router.back()}
      />
      
      <div className="pt-20 pb-20 px-4">
        {/* Game Mode Selection */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">গেম মোড নির্বাচন করুন</h2>
          <div className="grid grid-cols-2 gap-3">
            {gameModes.map((gameMode) => (
              <button
                key={gameMode.id}
                onClick={() => setSelectedMode(gameMode.id)}
                className={`!rounded-button p-4 rounded-xl text-left transition-all ${
                  selectedMode === gameMode.id
                    ? 'bg-orange-500 text-white shadow-lg scale-105'
                    : 'bg-white text-gray-800 shadow-md'
                }`}
              >
                <h3 className="font-medium text-sm mb-1">{gameMode.title}</h3>
                <p className={`text-xs ${selectedMode === gameMode.id ? 'text-white/80' : 'text-gray-600'}`}>
                  {gameMode.desc}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Play Options */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">খেলার ধরন</h2>
          <div className="space-y-3">
            {playOptions.map((option) => (
              <Link
                key={option.id}
                href={option.href}
                className="!rounded-button w-full bg-white p-4 rounded-xl shadow-md text-left flex items-center space-x-4"
              >
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <i className={`${option.icon} text-orange-500 text-xl`}></i>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-800">{option.title}</h3>
                  <p className="text-sm text-gray-600">{option.desc}</p>
                </div>
                <div className="w-6 h-6 flex items-center justify-center">
                  <i className="ri-arrow-right-line text-gray-400"></i>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Start Game Button */}
        <div className="space-y-4">
          <Link href="/game" className="!rounded-button block w-full bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 rounded-xl shadow-lg">
            <div className="flex items-center justify-center space-x-2">
              <i className="ri-play-fill text-xl"></i>
              <span className="font-semibold">খেলা শুরু করুন</span>
            </div>
          </Link>

          <button className="!rounded-button w-full bg-white border border-gray-300 text-gray-700 p-4 rounded-xl">
            <div className="flex items-center justify-center space-x-2">
              <i className="ri-settings-line"></i>
              <span>গেম সেটিংস</span>
            </div>
          </button>
        </div>

        {/* Quick Stats */}
        <div className="mt-8 bg-white rounded-xl p-4 shadow-md">
          <h3 className="font-medium text-gray-800 mb-3">আজকের পরিসংখ্যান</h3>
          <div className="grid grid-cols-3 text-center">
            <div>
              <p className="text-2xl font-bold text-green-500">12</p>
              <p className="text-xs text-gray-600">জিতেছেন</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-red-500">5</p>
              <p className="text-xs text-gray-600">হেরেছেন</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-orange-500">1,250</p>
              <p className="text-xs text-gray-600">পয়েন্ট</p>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
