
'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';

interface GamePiece {
  id: string;
  x: number;
  y: number;
  color: 'white' | 'black' | 'red' | 'striker';
  pocketed: boolean;
}

export default function GameContent() {
  const router = useRouter();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [currentPlayer, setCurrentPlayer] = useState(1);
  const [score, setScore] = useState({ player1: 0, player2: 0 });
  const [powerLevel, setPowerLevel] = useState(0);
  const [isAiming, setIsAiming] = useState(false);
  const [strikerPosition, setStrikerPosition] = useState({ x: 187.5, y: 350 });
  const [aimLine, setAimLine] = useState({ startX: 0, startY: 0, endX: 0, endY: 0 });

  const [gamePieces, setGamePieces] = useState<GamePiece[]>([
    // White pieces
    { id: 'w1', x: 187.5, y: 140, color: 'white', pocketed: false },
    { id: 'w2', x: 167.5, y: 160, color: 'white', pocketed: false },
    { id: 'w3', x: 207.5, y: 160, color: 'white', pocketed: false },
    { id: 'w4', x: 147.5, y: 180, color: 'white', pocketed: false },
    { id: 'w5', x: 187.5, y: 180, color: 'white', pocketed: false },
    { id: 'w6', x: 227.5, y: 180, color: 'white', pocketed: false },
    { id: 'w7', x: 167.5, y: 200, color: 'white', pocketed: false },
    { id: 'w8', x: 207.5, y: 200, color: 'white', pocketed: false },
    { id: 'w9', x: 187.5, y: 220, color: 'white', pocketed: false },
    
    // Black pieces
    { id: 'b1', x: 127.5, y: 160, color: 'black', pocketed: false },
    { id: 'b2', x: 247.5, y: 160, color: 'black', pocketed: false },
    { id: 'b3', x: 107.5, y: 180, color: 'black', pocketed: false },
    { id: 'b4', x: 267.5, y: 180, color: 'black', pocketed: false },
    { id: 'b5', x: 127.5, y: 200, color: 'black', pocketed: false },
    { id: 'b6', x: 247.5, y: 200, color: 'black', pocketed: false },
    { id: 'b7', x: 147.5, y: 220, color: 'black', pocketed: false },
    { id: 'b8', x: 227.5, y: 220, color: 'black', pocketed: false },
    
    // Red queen
    { id: 'red', x: 187.5, y: 190, color: 'red', pocketed: false },
    
    // Striker
    { id: 'striker', x: 187.5, y: 350, color: 'striker', pocketed: false }
  ]);

  useEffect(() => {
    drawGame();
  }, [gamePieces, aimLine, powerLevel]);

  const drawGame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw board background
    const gradient = ctx.createLinearGradient(0, 0, 375, 400);
    gradient.addColorStop(0, '#8B4513');
    gradient.addColorStop(1, '#A0522D');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 375, 400);

    // Draw board border
    ctx.strokeStyle = '#654321';
    ctx.lineWidth = 8;
    ctx.strokeRect(20, 20, 335, 360);

    // Draw center circle
    ctx.strokeStyle = '#444';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(187.5, 190, 30, 0, 2 * Math.PI);
    ctx.stroke();

    // Draw pockets
    const pockets = [
      { x: 35, y: 35 }, { x: 340, y: 35 }, 
      { x: 35, y: 365 }, { x: 340, y: 365 }
    ];
    
    pockets.forEach(pocket => {
      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(pocket.x, pocket.y, 15, 0, 2 * Math.PI);
      ctx.fill();
    });

    // Draw aim line
    if (isAiming && aimLine.startX !== aimLine.endX && aimLine.startY !== aimLine.endY) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.lineWidth = 3;
      ctx.setLineDash([8, 4]);
      ctx.beginPath();
      ctx.moveTo(aimLine.startX, aimLine.startY);
      ctx.lineTo(aimLine.endX, aimLine.endY);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw game pieces
    gamePieces.forEach(piece => {
      if (piece.pocketed) return;
      
      ctx.beginPath();
      ctx.arc(piece.x, piece.y, piece.id === 'striker' ? 14 : 12, 0, 2 * Math.PI);
      
      switch (piece.color) {
        case 'white':
          ctx.fillStyle = '#f8f8f8';
          ctx.strokeStyle = '#ccc';
          break;
        case 'black':
          ctx.fillStyle = '#2c2c2c';
          ctx.strokeStyle = '#000';
          break;
        case 'red':
          ctx.fillStyle = '#dc2626';
          ctx.strokeStyle = '#b91c1c';
          break;
        case 'striker':
          ctx.fillStyle = '#fbbf24';
          ctx.strokeStyle = '#f59e0b';
          break;
      }
      
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Add glow effect for striker
      if (piece.id === 'striker' && !piece.pocketed) {
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    });
  };

  const getCanvasCoordinates = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  // Mouse events
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!gameStarted) return;
    e.preventDefault();
    
    const { x, y } = getCanvasCoordinates(e.clientX, e.clientY);
    
    const striker = gamePieces.find(piece => piece.id === 'striker');
    if (striker && !striker.pocketed) {
      const distance = Math.sqrt(Math.pow(x - striker.x, 2) + Math.pow(y - striker.y, 2));
      if (distance <= 20) {
        setIsAiming(true);
        setAimLine({ startX: striker.x, startY: striker.y, endX: x, endY: y });
      }
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isAiming) return;
    e.preventDefault();
    
    const { x, y } = getCanvasCoordinates(e.clientX, e.clientY);
    
    const striker = gamePieces.find(piece => piece.id === 'striker');
    if (striker) {
      setAimLine({ startX: striker.x, startY: striker.y, endX: x, endY: y });
      
      // Auto-calculate power based on distance
      const distance = Math.sqrt(Math.pow(x - striker.x, 2) + Math.pow(y - striker.y, 2));
      const calculatedPower = Math.min(distance / 2, 100);
      setPowerLevel(calculatedPower);
    }
  };

  const handleCanvasMouseUp = () => {
    if (isAiming) {
      const shotPower = Math.min(powerLevel, 100);
      if (shotPower > 15) {
        simulateShot();
      }
      setIsAiming(false);
      setPowerLevel(0);
      setAimLine({ startX: 0, startY: 0, endX: 0, endY: 0 });
    }
  };

  // Touch events for mobile
  const handleCanvasTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (!gameStarted) return;
    e.preventDefault();
    
    const touch = e.touches[0];
    const { x, y } = getCanvasCoordinates(touch.clientX, touch.clientY);
    
    const striker = gamePieces.find(piece => piece.id === 'striker');
    if (striker && !striker.pocketed) {
      const distance = Math.sqrt(Math.pow(x - striker.x, 2) + Math.pow(y - striker.y, 2));
      if (distance <= 25) {
        setIsAiming(true);
        setAimLine({ startX: striker.x, startY: striker.y, endX: x, endY: y });
      }
    }
  };

  const handleCanvasTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (!isAiming) return;
    e.preventDefault();
    
    const touch = e.touches[0];
    const { x, y } = getCanvasCoordinates(touch.clientX, touch.clientY);
    
    const striker = gamePieces.find(piece => piece.id === 'striker');
    if (striker) {
      setAimLine({ startX: striker.x, startY: striker.y, endX: x, endY: y });
      
      // Auto-calculate power based on distance
      const distance = Math.sqrt(Math.pow(x - striker.x, 2) + Math.pow(y - striker.y, 2));
      const calculatedPower = Math.min(distance / 1.5, 100);
      setPowerLevel(calculatedPower);
    }
  };

  const handleCanvasTouchEnd = (e: React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (isAiming) {
      const shotPower = Math.min(powerLevel, 100);
      if (shotPower > 15) {
        simulateShot();
      }
      setIsAiming(false);
      setPowerLevel(0);
      setAimLine({ startX: 0, startY: 0, endX: 0, endY: 0 });
    }
  };

  const simulateShot = () => {
    // Simple collision simulation
    const randomHit = Math.random();
    if (randomHit > 0.2) {
      // Hit a piece
      const availablePieces = gamePieces.filter(p => !p.pocketed && p.id !== 'striker');
      if (availablePieces.length > 0) {
        const hitPiece = availablePieces[Math.floor(Math.random() * availablePieces.length)];
        
        // 50% chance to pocket the piece
        if (Math.random() > 0.5) {
          setGamePieces(prev => 
            prev.map(piece => 
              piece.id === hitPiece.id 
                ? { ...piece, pocketed: true }
                : piece
            )
          );
          
          // Update score
          if (hitPiece.color === 'white') {
            setScore(prev => ({ 
              ...prev, 
              [currentPlayer === 1 ? 'player1' : 'player2']: prev[currentPlayer === 1 ? 'player1' : 'player2'] + 1 
            }));
          } else if (hitPiece.color === 'black') {
            setScore(prev => ({ 
              ...prev, 
              [currentPlayer === 1 ? 'player2' : 'player1']: prev[currentPlayer === 1 ? 'player2' : 'player1'] + 1 
            }));
          } else if (hitPiece.color === 'red') {
            setScore(prev => ({ 
              ...prev, 
              [currentPlayer === 1 ? 'player1' : 'player2']: prev[currentPlayer === 1 ? 'player1' : 'player2'] + 5 
            }));
          }
        }
      }
    }
    
    // Switch player
    setCurrentPlayer(prev => prev === 1 ? 2 : 1);
  };

  const startGame = () => {
    setGameStarted(true);
  };

  const resetGame = () => {
    setGameStarted(false);
    setCurrentPlayer(1);
    setScore({ player1: 0, player2: 0 });
    setPowerLevel(0);
    setIsAiming(false);
    
    // Reset all pieces to original positions
    setGamePieces(prev => 
      prev.map(piece => ({ 
        ...piece, 
        pocketed: false,
        x: piece.id === 'striker' ? 187.5 : piece.x,
        y: piece.id === 'striker' ? 350 : piece.y
      }))
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      <Header 
        title="ক্যারাম গেম" 
        onBack={() => router.back()}
        rightAction={
          <button onClick={resetGame}>
            <i className="ri-refresh-line text-xl"></i>
          </button>
        }
      />
      
      <div className="pt-20 pb-20 px-4">
        {/* Score Display */}
        <div className="bg-white rounded-xl p-4 mb-4 shadow-md">
          <div className="grid grid-cols-2 text-center">
            <div className={`p-3 rounded-lg ${currentPlayer === 1 ? 'bg-orange-100 border-2 border-orange-300' : ''}`}>
              <p className="text-sm text-gray-600">খেলোয়াড় ১</p>
              <p className="text-2xl font-bold text-orange-500">{score.player1}</p>
            </div>
            <div className={`p-3 rounded-lg ${currentPlayer === 2 ? 'bg-red-100 border-2 border-red-300' : ''}`}>
              <p className="text-sm text-gray-600">খেলোয়াড় ২</p>
              <p className="text-2xl font-bold text-red-500">{score.player2}</p>
            </div>
          </div>
        </div>

        {/* Game Board */}
        <div className="bg-white rounded-2xl p-2 shadow-lg mb-4">
          <canvas
            ref={canvasRef}
            width={375}
            height={400}
            className="w-full border-2 border-gray-300 rounded-xl touch-none"
            style={{ touchAction: 'none' }}
            onMouseDown={handleCanvasMouseDown}
            onMouseMove={handleCanvasMouseMove}
            onMouseUp={handleCanvasMouseUp}
            onTouchStart={handleCanvasTouchStart}
            onTouchMove={handleCanvasTouchMove}
            onTouchEnd={handleCanvasTouchEnd}
          />
        </div>

        {/* Power Display */}
        {gameStarted && isAiming && (
          <div className="bg-white rounded-xl p-4 mb-4 shadow-md">
            <div className="text-center">
              <p className="text-sm text-gray-600 mb-2">শট শক্তি</p>
              <div className="w-full bg-gray-200 rounded-full h-4">
                <div 
                  className="bg-gradient-to-r from-green-400 to-red-500 h-4 rounded-full transition-all duration-150" 
                  style={{ width: `${powerLevel}%` }}
                ></div>
              </div>
              <p className="text-lg font-bold text-orange-500 mt-2">{Math.round(powerLevel)}%</p>
            </div>
          </div>
        )}

        {/* Current Player Display */}
        {gameStarted && (
          <div className="bg-white rounded-xl p-3 mb-4 shadow-md">
            <div className="text-center">
              <p className="text-sm text-gray-600">পালা</p>
              <p className={`text-lg font-bold ${currentPlayer === 1 ? 'text-orange-500' : 'text-red-500'}`}>
                খেলোয়াড় {currentPlayer}
              </p>
            </div>
          </div>
        )}

        {/* Game Controls */}
        <div className="space-y-3">
          {!gameStarted ? (
            <button 
              onClick={startGame}
              className="!rounded-button w-full bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 rounded-xl shadow-lg active:scale-95 transition-transform"
            >
              <div className="flex items-center justify-center space-x-2">
                <i className="ri-play-fill text-xl"></i>
                <span className="font-semibold">খেলা শুরু করুন</span>
              </div>
            </button>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={resetGame}
                className="!rounded-button bg-gray-500 text-white p-3 rounded-xl active:scale-95 transition-transform"
              >
                <div className="flex items-center justify-center space-x-2">
                  <i className="ri-refresh-line"></i>
                  <span>রিসেট</span>
                </div>
              </button>
              <button 
                onClick={() => router.back()}
                className="!rounded-button bg-red-500 text-white p-3 rounded-xl active:scale-95 transition-transform"
              >
                <div className="flex items-center justify-center space-x-2">
                  <i className="ri-close-line"></i>
                  <span>বন্ধ করুন</span>
                </div>
              </button>
            </div>
          )}
        </div>

        {/* Game Instructions */}
        {!gameStarted && (
          <div className="mt-4 bg-blue-50 rounded-xl p-4 shadow-md">
            <h3 className="font-medium text-blue-800 mb-2">মোবাইলে কিভাবে খেলবেন:</h3>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• স্বর্ণালী স্ট্রাইকারে টাচ করুন এবং টেনে লক্ষ্য ঠিক করুন</li>
              <li>• যত দূরে টানবেন তত বেশি শক্তি হবে</li>
              <li>• সাদা পক = ১ পয়েন্ট, কালো পক = প্রতিপক্ষের পয়েন্ট</li>
              <li>• লাল রানী = ৫ পয়েন্ট</li>
              <li>• স্ট্রাইকার ছেড়ে দিন শট নেওয়ার জন্য</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
