'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';

export default function ProfilePage() {
  const router = useRouter();
  const [user] = useState({
    name: 'খেলোয়াড়',
    avatar: '1',
    level: 15,
    xp: 7800,
    maxXp: 10000,
    rank: 'স্বর্ণ',
    wins: 142,
    losses: 58,
    totalGames: 200,
    winRate: 71,
    coins: 2500,
    trophies: 1850
  });

  const achievements = [
    { id: 1, title: 'প্রথম জয়', desc: 'প্রথমবার জিতুন', completed: true },
    { id: 2, title: 'দশ জয়', desc: '১০টি গেম জিতুন', completed: true },
    { id: 3, title: 'পারফেক্ট শট', desc: 'এক শটে সব পক পকেট করুন', completed: false },
    { id: 4, title: 'দৈনিক চ্যাম্পিয়ন', desc: 'একদিনে ২০টি গেম জিতুন', completed: false }
  ];

  const stats = [
    { label: 'মোট গেম', value: user.totalGames, icon: 'ri-gamepad-line' },
    { label: 'জয়ের হার', value: `${user.winRate}%`, icon: 'ri-trophy-line' },
    { label: 'সর্বোচ্চ স্ট্রিক', value: '12', icon: 'ri-fire-line' },
    { label: 'নিখুঁত শট', value: '23', icon: 'ri-target-line' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      <Header 
        title="প্রোফাইল" 
        onBack={() => router.back()}
        rightAction={
          <button>
            <i className="ri-settings-line text-xl"></i>
          </button>
        }
      />
      
      <div className="pt-20 pb-20 px-4">
        {/* Profile Header */}
        <div className="bg-white rounded-2xl p-6 mb-6 shadow-lg">
          <div className="text-center mb-4">
            <div className="w-20 h-20 mx-auto mb-4 overflow-hidden rounded-full">
              <img 
                src={`https://readdy.ai/api/search-image?query=3D%20cartoon%20character%20avatar%2C%20friendly%20game%20player%2C%20colorful%20character%20design%2C%20happy%20expression%2C%20gaming%20theme%2C%20centered%20composition%2C%20isolated%20on%20white%20background&width=150&height=150&seq=avatar-${user.avatar}&orientation=squarish`}
                alt="প্রোফাইল ছবি" 
                className="w-full h-full object-cover object-top"
              />
            </div>
            <h2 className="text-xl font-bold text-gray-800">{user.name}</h2>
            <p className="text-orange-500 font-medium">লেভেল {user.level} - {user.rank}</p>
          </div>

          {/* XP Progress */}
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-600 mb-1">
              <span>অভিজ্ঞতা</span>
              <span>{user.xp}/{user.maxXp}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-orange-400 to-red-400 h-2 rounded-full transition-all"
                style={{ width: `${(user.xp / user.maxXp) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 text-center border-t pt-4">
            <div>
              <p className="text-2xl font-bold text-green-500">{user.wins}</p>
              <p className="text-xs text-gray-600">জয়</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-red-500">{user.losses}</p>
              <p className="text-xs text-gray-600">পরাজয়</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-orange-500">{user.trophies}</p>
              <p className="text-xs text-gray-600">ট্রফি</p>
            </div>
          </div>
        </div>

        {/* Detailed Stats */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">বিস্তারিত পরিসংখ্যান</h3>
          <div className="grid grid-cols-2 gap-3">
            {stats.map((stat, index) => (
              <div key={index} className="bg-white p-4 rounded-xl shadow-md">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                    <i className={`${stat.icon} text-orange-500`}></i>
                  </div>
                  <div>
                    <p className="text-lg font-bold text-gray-800">{stat.value}</p>
                    <p className="text-xs text-gray-600">{stat.label}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">অর্জনসমূহ</h3>
          <div className="space-y-3">
            {achievements.map((achievement) => (
              <div key={achievement.id} className={`bg-white p-4 rounded-xl shadow-md ${
                achievement.completed ? 'border-l-4 border-green-400' : 'opacity-60'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-800">{achievement.title}</h4>
                    <p className="text-sm text-gray-600">{achievement.desc}</p>
                  </div>
                  <div className="w-8 h-8 flex items-center justify-center">
                    {achievement.completed ? (
                      <i className="ri-check-line text-green-500 text-xl"></i>
                    ) : (
                      <i className="ri-lock-line text-gray-400 text-xl"></i>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button className="!rounded-button w-full bg-white p-4 rounded-xl shadow-md flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <i className="ri-history-line text-orange-500 text-xl"></i>
              <span className="font-medium text-gray-800">খেলার ইতিহাস</span>
            </div>
            <i className="ri-arrow-right-line text-gray-400"></i>
          </button>

          <button className="!rounded-button w-full bg-white p-4 rounded-xl shadow-md flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <i className="ri-user-settings-line text-orange-500 text-xl"></i>
              <span className="font-medium text-gray-800">অ্যাকাউন্ট সেটিংস</span>
            </div>
            <i className="ri-arrow-right-line text-gray-400"></i>
          </button>

          <button className="!rounded-button w-full bg-white p-4 rounded-xl shadow-md flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <i className="ri-share-line text-orange-500 text-xl"></i>
              <span className="font-medium text-gray-800">বন্ধুদের আমন্ত্রণ জানান</span>
            </div>
            <i className="ri-arrow-right-line text-gray-400"></i>
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}