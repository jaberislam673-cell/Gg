
'use client';

import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
      <Header title="ক্যারাম পুল" />
      
      <div className="pt-20 pb-20 px-4">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <div className="mb-6">
            <img 
              src="https://readdy.ai/api/search-image?query=3D%20cartoon%20carom%20board%20game%20with%20wooden%20texture%2C%20traditional%20Indian%20board%20game%20setup%2C%20colorful%20game%20pieces%2C%20realistic%203D%20rendering%2C%20centered%20composition%2C%20warm%20lighting%2C%20game%20board%20from%20above%20view%2C%20professional%20game%20design&width=300&height=200&seq=hero-carom&orientation=landscape"
              alt="ক্যারাম বোর্ড" 
              className="w-full h-48 object-cover rounded-2xl shadow-lg"
            />
          </div>
          <h1 className="font-[\'Pacifico\'] text-3xl text-orange-600 mb-2">ক্যারাম পুল</h1>
          <p className="text-gray-600 text-sm">ক্লাসিক বোর্ড গেমের ডিজিটাল রূপ</p>
        </div>

        {/* Game Modes */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">গেম মোড</h2>
          <div className="grid grid-cols-2 gap-4">
            <Link href="/play?mode=classic" className="!rounded-button bg-white p-4 rounded-xl shadow-md">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 overflow-hidden rounded-full">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20classic%20carom%20board%2C%20wooden%20board%20with%20traditional%20markings%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20centered%20composition%2C%20isolated%20on%20white%20background&width=100&height=100&seq=classic-mode&orientation=squarish"
                    alt="ক্যারাম মোড" 
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <p className="text-sm font-medium text-gray-800">ক্যারাম মোড</p>
              </div>
            </Link>

            <Link href="/play?mode=diskpool" className="!rounded-button bg-white p-4 rounded-xl shadow-md">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 overflow-hidden rounded-full">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20pool%20disks%20scattered%2C%20colorful%20game%20pieces%2C%20fast-paced%20game%20style%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20centered%20composition%2C%20isolated%20on%20white%20background&width=100&height=100&seq=disk-pool&orientation=squarish"
                    alt="ডিস্ক পুল" 
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <p className="text-sm font-medium text-gray-800">ডিস্ক পুল</p>
              </div>
            </Link>

            <Link href="/play?mode=freestyle" className="!rounded-button bg-white p-4 rounded-xl shadow-md">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 overflow-hidden rounded-full">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20freestyle%20game%20elements%2C%20creative%20game%20pieces%20with%20points%2C%20modern%20gaming%20style%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20centered%20composition%2C%20isolated%20on%20white%20background&width=100&height=100&seq=freestyle&orientation=squarish"
                    alt="ফ্রিস্টাইল" 
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <p className="text-sm font-medium text-gray-800">ফ্রিস্টাইল</p>
              </div>
            </Link>

            <Link href="/play?mode=practice" className="!rounded-button bg-white p-4 rounded-xl shadow-md">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 overflow-hidden rounded-full">
                  <img 
                    src="https://readdy.ai/api/search-image?query=icon%2C%203D%20cartoon%20practice%20target%2C%20training%20elements%2C%20skill%20development%20theme%2C%20the%20icon%20should%20take%20up%2070%25%20of%20the%20frame%2C%20vibrant%20colors%20with%20soft%20gradients%2C%20minimalist%20design%2C%20smooth%20rounded%20shapes%2C%20centered%20composition%2C%20isolated%20on%20white%20background&width=100&height=100&seq=practice&orientation=squarish"
                    alt="প্র্যাকটিস" 
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <p className="text-sm font-medium text-gray-800">প্র্যাকটিস</p>
              </div>
            </Link>
          </div>
        </div>

        {/* Quick Play */}
        <div className="mb-8">
          <Link href="/game" className="!rounded-button block bg-gradient-to-r from-orange-500 to-red-500 text-white p-6 rounded-2xl text-center shadow-lg">
            <div className="w-8 h-8 mx-auto mb-2 flex items-center justify-center">
              <i className="ri-play-fill text-2xl"></i>
            </div>
            <h3 className="text-lg font-semibold">দ্রুত খেলুন</h3>
            <p className="text-sm opacity-90">এলোমেলো প্রতিপক্ষের সাথে খেলুন</p>
          </Link>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 gap-4">
          <div className="bg-white p-4 rounded-xl shadow-md">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 flex items-center justify-center">
                <i className="ri-global-line text-orange-500 text-xl"></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-800">অনলাইন মাল্টিপ্লেয়ার</h4>
                <p className="text-xs text-gray-600">বিশ্বজুড়ে খেলোয়াড়দের সাথে খেলুন</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-md">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 flex items-center justify-center">
                <i className="ri-group-line text-orange-500 text-xl"></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-800">বন্ধুদের সাথে খেলুন</h4>
                <p className="text-xs text-gray-600">প্রাইভেট রুম তৈরি করে আমন্ত্রণ পাঠান</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-md">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 flex items-center justify-center">
                <i className="ri-trophy-line text-orange-500 text-xl"></i>
              </div>
              <div>
                <h4 className="font-medium text-gray-800">লিডারবোর্ড</h4>
                <p className="text-xs text-gray-600">আপনার র‍্যাঙ্ক দেখুন এবং প্রতিযোগিতা করুন</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
